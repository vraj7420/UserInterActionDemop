package com.example.userintercationdemo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.TableLayout;

import com.google.android.material.tabs.TabLayout;

public class FragmentDemoActivity extends AppCompatActivity {

    private TabLayout tblFragment;
    private ViewPager  vpFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_demo);
        tblFragment=(TabLayout) findViewById(R.id.tblFragment);
        vpFragment= findViewById(R.id.vpFragment);
        vpFragment.setAdapter(new ViewPagerAdapter(getSupportFragmentManager()));

    }
    class ViewPagerAdapter extends FragmentPagerAdapter{

        String data[]={"Java","Android","Ios"};

        public ViewPagerAdapter(@NonNull FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
           if(position==0){
               return new Java();
           }
           if(position==1){
               return new Java();
           }
           if(position==1){
               return new AndroidFragment();
           }
           if(position==2){
               return new IosFragment();
           }
            return null;
        }

        @Override
        public int getCount() {
            return data.length;
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return data[position];
        }
    }

}
